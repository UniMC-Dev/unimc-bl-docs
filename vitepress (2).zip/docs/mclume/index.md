---
next:
  text: '区服介绍'
  link: '/docs/mclume/play/区服'
---
# 欢迎来到 **MCLUME**:high_brightness:
**:diamond_shape_with_a_dot_inside:体验至上 开放权限**
## 服务器简介:star:
- **中文名**：麦熙
- **腐竹**：老八、Koshca
- **服务器IP：ml.unimc.homes**
- **基岩版端口：29810（IP同上）**
- **主服版本：1.21.4，可跨版本进入**
 
**致力于给玩家最好的体验**
 
**至今累计运营五载**
## 须知事项:exclamation:
- **请认真阅读 [常见问题](/docs/all/ask) 及 [游玩守则](/docs/all/rules.html#游玩守则)**
- **关注群公告以获取最新内容**
- **询问 群友/管理员 以获得帮助**
## 加入我们:iphone:
 
- **QQ群：[71951909](https://qm.qq.com/q/yWpttnMwfe)**
 
- **服务器 [官网](https://www.mcpool.net)**
 
- **UNIMC [论坛](https://bbs.unimc.homes)**