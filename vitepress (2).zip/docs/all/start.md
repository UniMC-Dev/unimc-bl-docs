# MCLUME X MCBUCKET :tada:
**开放 尊重 始终如一**
> 本文档将持续完善，欢迎提出宝贵意见！ 
## :clipboard:游玩须知
>[!caution] 注意
>**两服共用一套基本守则，请确保严格遵守它**
>**[点击查看](./rules.md)。**
::: tip
服务器凌晨定时重启，保证流畅运行
:::
::: details 进服流程 点击展开 
> **请分清：I（大写 I），l（小写 L），1（数字 1）和 0（数字 0），O（大写 o）**
1. 通过QQ群获取服务器IP
2. 进入服务器
3. 发送：绑定 <验证码> 至群聊
 
示例：
![图片](/public/server_enter.png "进")
![图片](/public/enter_code.png "输")
:::
<Linkcard url="/docs/mclume/play" title="MCLUME WIKI" description="快速跳转" logo="/mlicon.png"/>
 
<Linkcard url="/docs/mclume/play" title="MCBUCKET WIKI" description="快速跳转" logo="/mbicon.png"/>

## :family:管理团队
**৹ 老八**
  
**৹ XiaoZhe Nice**
 
**৹ Koshca**
 
**৹ Bili_emo**
 
**৹ Fire_Fly**
 
**৹ Yuluo**